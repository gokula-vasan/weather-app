from flask import Flask, render_template, request
import requests
from datetime import datetime

app = Flask(__name__)
API_KEY = "c79ddd084e8e5a1d17234a4fc52c13a3"  

@app.route('/', methods=['GET', 'POST'])
def index():
    weather_data = None
    now = datetime.now()  
    current_time = now.strftime("%d-%m-%Y | %H:%M:%S")  
    if request.method == 'POST':
        city = request.form['city']
        url = f"https://api.openweathermap.org/data/2.5/weather?q={city}&appid={API_KEY}&units=metric"
        response = requests.get(url)
        data = response.json()

        if data.get('main'):
            weather_data = {
                'city': city,
                'temperature': data['main']['temp'],
                'description': data['weather'][0]['description'].capitalize(),
                'icon': data['weather'][0]['icon']
            }
        else:
            weather_data = {'error': 'City not found'}

    return render_template('index.html', weather=weather_data, time=current_time)  
if __name__ == '__main__':
    app.run(debug=True)
